import numpy as np

u = np.array([1, 2, 4])
v = np.array([2, -3, 5])
w = np.array([4, 2, -3])

print("u · v =", np.dot(u, v))  # 16
print("u · w =", np.dot(u, w))  # -4
print("v · w =", np.dot(v, w))  # -13

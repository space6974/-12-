import numpy as np

u = np.array([2, -5, -1])
v = np.array([-7, -4, 6])

# (1) 내적
dot_product = np.dot(u, v)

# (2) u의 길이의 제곱
squared_norm_u = np.dot(u, u)

# (3) 두 벡터 사이 거리의 제곱
difference = u - v
squared_distance = np.dot(difference, difference)

print("u · v =", dot_product)          # 0
print("||u||² =", squared_norm_u)      # 30
print("||u-v||² =", squared_distance)  # 131

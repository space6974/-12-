import numpy as np

u = np.array([1, 2], dtype=float)
v = np.array([6, -3], dtype=float)

dot_product = np.dot(u, v)
norm_u = np.linalg.norm(u)
norm_v = np.linalg.norm(v)

print(f"내적 = {dot_product:.6f}")

if norm_u == 0 or norm_v == 0:
    print("영벡터가 포함되어 각도는 정의되지 않습니다.")
else:
    cos_theta = dot_product / (norm_u * norm_v)
    cos_theta = np.clip(cos_theta, -1.0, 1.0)

    theta_deg = np.degrees(np.arccos(cos_theta))
    is_orthogonal = np.isclose(dot_product, 0.0, atol=1e-10, rtol=0.0)

    print(f"cos(theta) = {cos_theta:.6f}")
    print(f"각도 = {theta_deg:.6f}°")
    print("직교합니다." if is_orthogonal else "직교하지 않습니다.")
